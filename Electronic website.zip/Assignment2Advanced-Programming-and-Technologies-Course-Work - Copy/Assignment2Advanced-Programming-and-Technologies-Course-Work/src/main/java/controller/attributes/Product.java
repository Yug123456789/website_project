package controller.attributes;

public class Product {
    private int id;
    private String name;

    private String brand;
    private String ProductPhoto;
    private double price;
    private int stock;
    private String description;

    public Product(int id, String name,String brand, String ProductPhoto, double price, int stock, String description) {
        this.id = id;
        this.name = name;
       
        this.brand = brand;
        this.ProductPhoto = ProductPhoto;
        this.price = price;
        this.stock = stock;
        this.description= description;
    }

    // Getter methods for each private field

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }

    public String getPhoto() {
        return ProductPhoto;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public String getDescription() {
        return description;
    }
}
