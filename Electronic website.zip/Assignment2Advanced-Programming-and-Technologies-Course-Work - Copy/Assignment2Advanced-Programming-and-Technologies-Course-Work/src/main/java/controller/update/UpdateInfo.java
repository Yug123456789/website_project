package controller.update;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.DAO.UserDAO;

@WebServlet("/update-info")
@MultipartConfig
public class UpdateInfo extends HttpServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("i am in ");
		HttpSession session = request.getSession(false);
		String attributeName = "loggedInId";
		String currentUser = (String) session.getAttribute(attributeName);
		
		System.out.println("user"+currentUser);
		
		
		String name=request.getParameter("newName");
		String email=request.getParameter("newEmail");
		String gender = request.getParameter("newGender");
		String password = request.getParameter("newPassword");
		
		System.out.println(name);
		
		
		
		
		String message =  new UserDAO().updateUserInfo(name,email,password,currentUser);
		
		
//		if (message.equals("Successfully Updated") && profilePhoto != null && profilePhoto.getInputStream().available()>0){
//			String imagePath="/home/kabin/eclipse-workspaceow/Java-Group-Course-Work/src/main/webapp/images/";
//			String fullPath=imagePath+userProfilePath;
//			
//			profilePhoto.write(fullPath);
//		}
		HttpSession session1=request.getSession();
		session1.setAttribute("updateInfoMessage", message);
		response.sendRedirect("profile.jsp");
		
	}
}